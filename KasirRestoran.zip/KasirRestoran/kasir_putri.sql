-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2024 at 03:31 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kasir_putri`
--

-- --------------------------------------------------------

--
-- Table structure for table `detailpesanan`
--

CREATE TABLE `detailpesanan` (
  `id_barang` int(35) NOT NULL,
  `id_detail` int(35) NOT NULL,
  `qty` int(35) NOT NULL,
  `status` varchar(20) NOT NULL,
  `total` int(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detailpesanan`
--

INSERT INTO `detailpesanan` (`id_barang`, `id_detail`, `qty`, `status`, `total`) VALUES
(7, 1, 1, 'Belum Lunas', 85000),
(11, 4, 1, 'Belum Lunas', 80000),
(3, 6, 2, 'Belum Lunas', 114000),
(7, 8, 1, 'Belum Lunas', 100000),
(7, 9, 1, 'Belum Lunas', 90000),
(7, 10, 1, 'Belum Lunas', 60000);

--
-- Triggers `detailpesanan`
--
DELIMITER $$
CREATE TRIGGER `update_stok_barang` AFTER INSERT ON `detailpesanan` FOR EACH ROW UPDATE tb_barang
SET stok = stok - new.qty
WHERE id_barang = new.id_barang
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(35) NOT NULL,
  `jenis_kategori` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `jenis_kategori`) VALUES
(1, 'baju muslim dewasa'),
(2, 'baju koko dewasa'),
(3, 'baju muslim anak-anak'),
(4, 'baju tidur anak-anak'),
(5, 'baju tidur dewasa'),
(6, 'baju koko anak-anak'),
(7, 'baju tidur anak-anak'),
(8, 'baju tidur dewasa'),
(9, 'jas'),
(10, 'kemeja');

-- --------------------------------------------------------

--
-- Table structure for table `log_admin`
--

CREATE TABLE `log_admin` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(30) NOT NULL,
  `email` varchar(35) NOT NULL,
  `password` varchar(30) NOT NULL,
  `handphone` int(35) NOT NULL,
  `level` enum('admin','kasir','manager') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log_admin`
--

INSERT INTO `log_admin` (`id_user`, `nama_user`, `email`, `password`, `handphone`, `level`) VALUES
(1, 'yusuf', 'y@gmail.com', '123', 2345678, 'admin'),
(2, 'novita', 'n@gmail.com', '123', 87654567, 'kasir'),
(3, 'raisa', 'r@gmail.com', '123', 87654567, 'manager');

-- --------------------------------------------------------

--
-- Table structure for table `log_barang`
--

CREATE TABLE `log_barang` (
  `status` varchar(30) NOT NULL,
  `waktu` date NOT NULL,
  `nama_baju` varchar(50) NOT NULL,
  `harga` int(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log_barang`
--

INSERT INTO `log_barang` (`status`, `waktu`, `nama_baju`, `harga`) VALUES
('sudah bayar', '2024-01-01', 'dress pink', 85);

-- --------------------------------------------------------

--
-- Table structure for table `log_detail`
--

CREATE TABLE `log_detail` (
  `status` varchar(30) NOT NULL,
  `waktu` date NOT NULL,
  `id_detail` int(15) NOT NULL,
  `id_barang` int(15) NOT NULL,
  `qty` int(15) NOT NULL,
  `total` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log_detail`
--

INSERT INTO `log_detail` (`status`, `waktu`, `id_detail`, `id_barang`, `qty`, `total`) VALUES
('sudah bayar', '2024-01-01', 1, 1, 3, 150000);

-- --------------------------------------------------------

--
-- Table structure for table `log_master`
--

CREATE TABLE `log_master` (
  `status` varchar(30) NOT NULL,
  `waktu` date NOT NULL,
  `id_master` int(35) NOT NULL,
  `id_detail` int(35) NOT NULL,
  `id_user` int(35) NOT NULL,
  `tgl_byr` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log_master`
--

INSERT INTO `log_master` (`status`, `waktu`, `id_master`, `id_detail`, `id_user`, `tgl_byr`) VALUES
('sudah bayar', '2024-01-09', 888, 777, 6666, '2024-01-02');

-- --------------------------------------------------------

--
-- Table structure for table `masterpesan`
--

CREATE TABLE `masterpesan` (
  `id_master` int(35) NOT NULL,
  `id_detail` int(35) NOT NULL,
  `id_user` int(35) NOT NULL,
  `tgl_byr` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `masterpesan`
--

INSERT INTO `masterpesan` (`id_master`, `id_detail`, `id_user`, `tgl_byr`) VALUES
(2, 6, 2, '2024-01-17'),
(3, 9, 2, '2024-01-01'),
(4, 1, 2, '2024-02-14'),
(5, 1, 2, '2024-02-17');

-- --------------------------------------------------------

--
-- Table structure for table `satuan`
--

CREATE TABLE `satuan` (
  `id_satuan` int(35) NOT NULL,
  `jenis_satuan` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `satuan`
--

INSERT INTO `satuan` (`id_satuan`, `jenis_satuan`) VALUES
(1, 'kodi'),
(2, 'lusin'),
(5, 'pcs');

-- --------------------------------------------------------

--
-- Table structure for table `tb_barang`
--

CREATE TABLE `tb_barang` (
  `id_barang` int(30) NOT NULL,
  `nama_barang` varchar(35) NOT NULL,
  `id_kategori` int(35) NOT NULL,
  `id_satuan` varchar(30) NOT NULL,
  `harga_beli` decimal(30,0) NOT NULL,
  `harga_jual` decimal(35,0) NOT NULL,
  `stok` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_barang`
--

INSERT INTO `tb_barang` (`id_barang`, `nama_barang`, `id_kategori`, `id_satuan`, `harga_beli`, `harga_jual`, `stok`) VALUES
(1, 'kaos oversize polos', 3, '1', '45000', '85000', 15),
(2, 'kemeja putih', 10, '1', '50000', '75000', 13),
(3, 'dress pink', 5, '1', '45000', '80000', 18),
(4, 'piama pink', 5, '5', '50000', '80000', 25),
(5, 'koko putih', 4, '2', '75000', '90000', 10),
(6, 'gamis Hitam', 1, '1', '50000', '57000', 15),
(7, 'cardigan', 4, '2', '40000', '75000', 17),
(8, 'jas putih', 9, '1', '30000', '100000', 10),
(9, 'jas hitam', 9, '1', '40000', '90000', 17),
(10, 'kemeja army ', 10, '5', '45000', '60000', 18);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(30) NOT NULL,
  `email` varchar(35) NOT NULL,
  `password` varchar(20) NOT NULL,
  `handphone` int(35) NOT NULL,
  `level` enum('admin','kasir','manager') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama_user`, `email`, `password`, `handphone`, `level`) VALUES
(2, 'novita', 'n@gmail.com', '123', 823457876, 'kasir'),
(3, 'raisa', 'r@gmail.com', '123', 975335876, 'manager'),
(11, 'sindy', 's@gmail.com', '123', 876543, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detailpesanan`
--
ALTER TABLE `detailpesanan`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `id_barang` (`id_barang`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `log_admin`
--
ALTER TABLE `log_admin`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `masterpesan`
--
ALTER TABLE `masterpesan`
  ADD PRIMARY KEY (`id_master`),
  ADD KEY `id_detail` (`id_detail`);

--
-- Indexes for table `satuan`
--
ALTER TABLE `satuan`
  ADD PRIMARY KEY (`id_satuan`);

--
-- Indexes for table `tb_barang`
--
ALTER TABLE `tb_barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
